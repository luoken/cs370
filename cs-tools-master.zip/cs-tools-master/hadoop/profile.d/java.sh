export JAVA_HOME=/usr/lib/jvm/java-1.7.0
